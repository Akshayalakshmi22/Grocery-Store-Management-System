package com.grocery.config;

public class JwtConstant {
	public static final String SECRET_KEY = "gdkjewjdunjdjcjecenkjijswdjnzkakoxjscbnksd";
	public static final String JWT_HEADER = "Authorization";

}
