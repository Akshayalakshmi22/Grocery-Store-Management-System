package com.grocery.model;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Grocery {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	private String name;
	private Long price;
	
	@ManyToOne
	private Category groceryCategory;
	
	@Column(length=1000)
	@ElementCollection
	private List<String> images;
	
	private boolean available;
	
	@ManyToOne
	private Store store;
	
	private Date creationDate;
	@PrePersist
    protected void onCreate() {
        creationDate = Date.valueOf(LocalDate.now());
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getPrice() {
		return price;
	}

	public void setPrice(Long price) {
		this.price = price;
	}

	public Category getGroceryCategory() {
		return groceryCategory;
	}

	public void setGroceryCategory(Category groceryCategory) {
		this.groceryCategory = groceryCategory;
	}

	public List<String> getImages() {
		return images;
	}

	public void setImages(List<String> images) {
		this.images = images;
	}

	public boolean isAvailable() {
		return available;
	}

	public void setAvailable(boolean available) {
		this.available = available;
	}

	public Store getStore() {
		return store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Grocery(Long id, String name, Long price, Category groceryCategory, List<String> images, boolean available,
			Store store, Date creationDate) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.groceryCategory = groceryCategory;
		this.images = images;
		this.available = available;
		this.store = store;
		this.creationDate = creationDate;
	}

	public Grocery() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
