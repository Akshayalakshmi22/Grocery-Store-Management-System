package com.grocery.model;

public enum USER_ROLE {
	ROLE_CUSTOMER,
	ROLE_STORE_OWNER,
	ROLE_ADMIN
}
