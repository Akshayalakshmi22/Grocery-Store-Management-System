package com.grocery.service;

import java.util.List;

import com.grocery.model.Customer;
import com.grocery.model.Order;
import com.grocery.request.OrderRequest;

public interface OrderService {
	
	public Order createOrder(OrderRequest order,Customer user)throws Exception;
	
	public Order updateOrderStatus(Long orderId, String orderStatus)throws Exception;//updateOrder
	
	public void cancelOrder(Long orderId)throws Exception;
	
	public List<Order> getUsersOrder(Long userId)throws Exception;
	
	public List<Order> getStoresOrder(Long storeId,String orderStatus)throws Exception;
	
	public Order findOrderById(Long orderId)throws Exception;
}
