package com.grocery.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grocery.model.Category;
import com.grocery.model.Grocery;
import com.grocery.model.Store;
import com.grocery.repository.GroceryRepository;
import com.grocery.request.CreateGroceryRequest;

@Service
public class GroceryServiceImp implements GroceryService{
	@Autowired
	private GroceryRepository groceryRepository;

	@Override
	public Grocery createGrocery(CreateGroceryRequest req, Category category, Store store) {
		// TODO Auto-generated method stub
		Grocery grocery = new Grocery();
		grocery.setGroceryCategory(category);
		grocery.setStore(store);
		grocery.setImages(req.getImages());
		grocery.setPrice(req.getPrice());
		grocery.setName(req.getName());
		
		Grocery savedGrocery = groceryRepository.save(grocery);
		store.getGrocery().add(savedGrocery);
		return savedGrocery;
	}

	@Override
	public void deleteGrocery(Long groceryId) throws Exception {
		// TODO Auto-generated method stub
		Grocery grocery = findGroceryById(groceryId);
		grocery.setStore(null);
		groceryRepository.save(grocery);
		
	}

	@Override
	public List<Grocery> getStoresGrocery(Long storeId, String groceryCategory) {
		// TODO Auto-generated method stub
		List<Grocery> groceries = groceryRepository.findByStoreId(storeId);
		if(groceryCategory!=null && !groceryCategory.equals("")) {
			groceries= filterByCategory(groceries,groceryCategory);
		}
		return null;
	}

	private List<Grocery> filterByCategory(List<Grocery> groceries, String groceryCategory) {
		// TODO Auto-generated method stub
		return groceries.stream().filter(grocery -> {
			if(grocery.getGroceryCategory()!=null) {
				return grocery.getGroceryCategory().getName().equals(groceryCategory);
			}
			return false;
		}).collect(Collectors.toList());
	}

	@Override
	public List<Grocery> searchGrocery(String keyword) {
		// TODO Auto-generated method stub
		return groceryRepository.searchGrocery(keyword);
	}

	@Override
	public Grocery findGroceryById(Long groceryId) throws Exception {
		// TODO Auto-generated method stub
		Optional<Grocery> optionalGrocery=groceryRepository.findById(groceryId);
		if(optionalGrocery.isEmpty()) {
			throw new Exception("Grocery Not Exist...");
		}
		return optionalGrocery.get();
	}

	@Override
	public Grocery updateAvailabilityStatus(Long groceryId) throws Exception {
		// TODO Auto-generated method stub
		Grocery grocery = findGroceryById(groceryId);
		grocery.setAvailable(!grocery.isAvailable());
		return groceryRepository.save(grocery);
		
	}

}
