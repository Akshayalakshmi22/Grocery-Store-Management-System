package com.grocery.service;

import java.util.ArrayList;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grocery.model.Address;
import com.grocery.model.Cart;
import com.grocery.model.CartItem;
import com.grocery.model.Customer;
import com.grocery.model.Order;
import com.grocery.model.OrderItem;
import com.grocery.model.Store;
import com.grocery.repository.AddressRepository;
import com.grocery.repository.OrderItemRepository;
import com.grocery.repository.OrderRepository;
import com.grocery.repository.UserRepository;
import com.grocery.request.OrderRequest;

@Service
public class OrderServiceImp implements OrderService{
	@Autowired
	private OrderRepository orderRepository; 
	@Autowired
	private OrderItemRepository orderItemRepository; 
	@Autowired
	private AddressRepository addressRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
    private StoreService storeService;
	@Autowired
    private CartService cartService;

	@Override
	public Order createOrder(OrderRequest order, Customer user) throws Exception {
		// TODO Auto-generated method stub
		Address shippingAddress=order.getDeliveryAddress();
		Address savedAddress=addressRepository.save(shippingAddress);
		if(!user.getAddresses().contains(savedAddress)) {
			user.getAddresses().add(savedAddress);
			userRepository.save(user);
		}
		Store store=storeService.findStoreById(order.getStoreId());
		Order createdOrder=new Order();
		createdOrder.setCustomer(user);
		createdOrder.setCreatedAt(new Date());
		createdOrder.setOrderStatus("PENDING");
		createdOrder.setDeliverAddress(savedAddress);
		createdOrder.setStore(store);
		
		Cart cart = cartService.findCartByUserId(user.getCustomerId());
		List<OrderItem> orderItems=new ArrayList<>();
		for(CartItem cartItem : cart.getItems()) {
			OrderItem orderItem = new OrderItem();
			orderItem.setGrocery(cartItem.getGrocery());
			orderItem.setQuantity(cartItem.getQuantity());
			orderItem.setTotalPrice(cartItem.getTotalPrice());
			
			OrderItem savedOrderItem=orderItemRepository.save(orderItem);
			orderItems.add(savedOrderItem);	
		}
		Long totalPrice = cartService.calculateCartTotals(cart);
		createdOrder.setItems(orderItems);
		createdOrder.setTotalPrice(totalPrice);
		
		Order savedOrder = orderRepository.save(createdOrder);
		store.getOrders().add(savedOrder);
		return createdOrder ;
	}

	@Override
	public Order updateOrderStatus(Long orderId, String orderStatus) throws Exception {//updateOrder
		// TODO Auto-generated method stub
		Order order = findOrderById(orderId);
		if(orderStatus.equals("OUT_FOR_DELIVERY") 
		   || orderStatus.equals("DELIVERED") 
		   || orderStatus.equals("COMPLETED")
		   || orderStatus.equals("PENDING")) {
			order.setOrderStatus(orderStatus);
			return orderRepository.save(order);
		}
		throw new Exception("Please Select A Valid Order Status");
	}

	@Override
	public void cancelOrder(Long orderId) throws Exception {
		// TODO Auto-generated method stub
		Order order = findOrderById(orderId);
		orderRepository.deleteById(orderId);
	}

	@Override
	public List<Order> getUsersOrder(Long userId) throws Exception {
		// TODO Auto-generated method stub
		return orderRepository.findByCustomerCustomerId(userId);
	}

	@Override
	public List<Order> getStoresOrder(Long storeId, String orderStatus) throws Exception {
		// TODO Auto-generated method stub
		List<Order>orders=orderRepository.findByStoreId(storeId);
		if(orderStatus!=null) {
			orders = orders.stream().filter(order->
										  order.getOrderStatus().equals(orderStatus)).collect(Collectors.toList());
		}
		return orders;
	}

	@Override
	public Order findOrderById(Long orderId) throws Exception {
		// TODO Auto-generated method stub
		Optional<Order> optionalOrder=orderRepository.findById(orderId);
		if(optionalOrder.isEmpty()) {
			throw new Exception("Order Not Found");
		}
		return optionalOrder.get();
	}

}
