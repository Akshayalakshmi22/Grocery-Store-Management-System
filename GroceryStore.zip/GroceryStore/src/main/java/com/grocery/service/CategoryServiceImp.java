package com.grocery.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grocery.model.Category;
import com.grocery.model.Store;
import com.grocery.repository.CategoryRepository;

@Service
public class CategoryServiceImp implements CategoryService{
	
	@Autowired
	private StoreService storeService;
	
	@Autowired
	private CategoryRepository categoryRepository;

	@Override
	public Category createCategory(String name, Long userId) throws Exception {
		// TODO Auto-generated method stub
		Store store = storeService.getStoreByUserId(userId);
		Category category = new Category();
		category.setName(name);
		category.setStore(store);
		return categoryRepository.save(category);
	}

	@Override
	public List<Category> findCategoryByStoreId(Long id) throws Exception {
		// TODO Auto-generated method stub
		Store store = storeService.getStoreByUserId(id);
		return categoryRepository.findByStoreId(store.getId());
	}

	@Override
	public Category findCategoryById(Long id) throws Exception {
		// TODO Auto-generated method stub
		Optional<Category> optionalCategory = categoryRepository.findById(id);
		if(optionalCategory.isEmpty()) {
			throw new Exception("Category Not Found!!");
		}
		return optionalCategory.get();
	}
	

}
