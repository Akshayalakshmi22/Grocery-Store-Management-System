package com.grocery.service;

import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grocery.model.Cart;
import com.grocery.model.CartItem;
import com.grocery.model.Customer;
import com.grocery.model.Grocery;
import com.grocery.repository.CartItemRepository;
import com.grocery.repository.CartRepository;
import com.grocery.request.AddCartItemRequest;

@Service
public class CartServiceImp implements CartService{
	@Autowired
	private CartRepository cartRepository;
	@Autowired
	private UserService userService;
	@Autowired
	private CartItemRepository cartItemRepository;
	@Autowired
	private GroceryService groceryService;
	

	@Override
	public CartItem addItemToCart(AddCartItemRequest req, String jwt) throws Exception {
		// TODO Auto-generated method stub
		Customer user = userService.findUserByJwtToken(jwt);
		Grocery grocery = groceryService.findGroceryById(req.getGroceryId());
		Cart cart = cartRepository.findByCustomerCustomerId(user.getCustomerId());
		for(CartItem cartItem : cart.getItems()) {
			if(cartItem.getGrocery().equals(grocery)) {
				int newQuantity = cartItem.getQuantity()+req.getQuantity();
				return updateCartItemQuantity(cartItem.getId(),newQuantity);
			}
		}
		CartItem newCartItem = new CartItem();
		newCartItem.setGrocery(grocery);
		newCartItem.setCart(cart);
		newCartItem.setQuantity(req.getQuantity());
		newCartItem.setTotalPrice(req.getQuantity()*grocery.getPrice());
		
		CartItem savedCartItem = cartItemRepository.save(newCartItem);
		cart.getItems().add(savedCartItem);
		
		return savedCartItem;
	}

	@Override
	public CartItem updateCartItemQuantity(Long cartItemId, int quantity) throws Exception {
		// TODO Auto-generated method stub
		Optional<CartItem> cartItemOptional=cartItemRepository.findById(cartItemId);
		if(cartItemOptional.isEmpty()) {
			throw new Exception("Cart Item Not Found");
		}
		CartItem item = cartItemOptional.get();
		item.setQuantity(quantity);
		item.setTotalPrice(item.getGrocery().getPrice()*quantity);
		return cartItemRepository.save(item);
	}

	@Override
	public Cart removeItemFromCart(Long cartItemId, String jwt) throws Exception {
		// TODO Auto-generated method stub
		Customer user = userService.findUserByJwtToken(jwt);
		Cart cart = cartRepository.findByCustomerCustomerId(user.getCustomerId());
		Optional<CartItem> cartItemOptional=cartItemRepository.findById(cartItemId);
		if(cartItemOptional.isEmpty()) {
			throw new Exception("Cart Item Not Found");
		}
		CartItem item = cartItemOptional.get();
		cart.getItems().remove(item);
		
		return cartRepository.save(cart);
	}

	@Override
	public Long calculateCartTotals(Cart cart) throws Exception {
		// TODO Auto-generated method stub
		Long total = 0L;
		for(CartItem cartItem : cart.getItems()) {
			total+=cartItem.getGrocery().getPrice()*cartItem.getQuantity();
		}
		return total;
	}

	@Override
	public Cart findCartById(Long id) throws Exception {
		// TODO Auto-generated method stub
		Optional<Cart>optionalCart=cartRepository.findById(id);
		if(optionalCart.isEmpty()) {
			throw new Exception("Cart Not Found With Id "+id);
		}
		return optionalCart.get();
	}

	@Override
	public Cart findCartByUserId(Long userId) throws Exception {
		// TODO Auto-generated method stub
		Cart cart = cartRepository.findByCustomerCustomerId(userId);
		cart.setTotal(calculateCartTotals(cart));
		return cart;
	}

	@Override
	public Cart clearCart(Long userId) throws Exception {
		// TODO Auto-generated method stub
		Cart cart = findCartByUserId(userId);;
		cart.getItems().clear();
		return cartRepository.save(cart);
	}

}
