package com.grocery.service;

import java.time.LocalDateTime;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grocery.dto.StoreDto;
import com.grocery.model.Address;
import com.grocery.model.Customer;
import com.grocery.model.Store;
import com.grocery.repository.AddressRepository;
import com.grocery.repository.StoreRepository;
import com.grocery.repository.UserRepository;
import com.grocery.request.CreateStoreRequest;

@Service
public class StoreServiceImp implements StoreService{
	@Autowired
	private StoreRepository storeRepository;
	@Autowired
	private AddressRepository addressRepository;
	@Autowired
	private UserRepository userRepository;

	@Override
	public Store createStore(CreateStoreRequest req, Customer user) {
		// TODO Auto-generated method stub
		Address address = addressRepository.save(req.getAddress());
		
		Store store = new Store();
		store.setAddress(address);
		store.setContactInformation(req.getContactInformation());
		store.setImages(req.getImages());
		store.setName(req.getName());
		store.setOpeningHours(req.getOpeningHours());
		store.setRegistrationDate(LocalDateTime.now());
		store.setOwner(user);
		
		return storeRepository.save(store);
	}

	@Override
	public Store updateStore(Long storeId, CreateStoreRequest updatedStore) throws Exception {
		// TODO Auto-generated method stub
		Store store = findStoreById(storeId);
		if(store.getName()!=null) {
			store.setName(updatedStore.getName());
		}
		return storeRepository.save(store);
	}

	@Override
	public void deleteStore(Long storeId) throws Exception {
		// TODO Auto-generated method stub
		Store store = findStoreById(storeId);
		storeRepository.delete(store);
		
	}

	@Override
	public List<Store> getAllStore() {
		// TODO Auto-generated method stub
		return storeRepository.findAll();
	}

	@Override
	public List<Store> searchStore(String keyword) {
		// TODO Auto-generated method stub
		return storeRepository.findBySearchQuery(keyword);
	}

	@Override
	public Store findStoreById(Long id) throws Exception {
		// TODO Auto-generated method stub
		Optional<Store> opt = storeRepository.findById(id);
		if(opt.isEmpty()) {
			throw new Exception("Store Not Found With Id "+id);
		}
		return opt.get();
	}

	@Override
	public Store getStoreByUserId(Long customerId) throws Exception {
		// TODO Auto-generated method stub
		Store store = storeRepository.findByOwnerCustomerId(customerId);
		if(store==null) {
			throw new Exception("Store Not Found With Owner Id "+customerId);
		}
		
		return store;
	}

	@Override
	public StoreDto addToFavorites(Long storeId, Customer user) throws Exception {
		// TODO Auto-generated method stub
		Store store = findStoreById(storeId);
		StoreDto dto = new StoreDto();
		dto.setImages(store.getImages());
		dto.setTitle(store.getName());
		dto.setId(storeId);
		
		boolean isFavorite = false;
		List<StoreDto> favorites = user.getFavorites();
		for(StoreDto favorite : favorites) {
			if(favorite.getId()== storeId) {
				isFavorite = true;
				break;
			}
		}
		
		if(isFavorite) {
			favorites.removeIf(favorite -> favorite.getId()==storeId);
		}
		else {
			favorites.add(dto);
		}
		
		userRepository.save(user);
		return dto;
	}

	@Override
	public Store updateStoreStatus(Long id) throws Exception {
		// TODO Auto-generated method stub
		Store store = findStoreById(id);
		store.setOpen(!store.isOpen());
		return storeRepository.save(store);
	}
	

}
