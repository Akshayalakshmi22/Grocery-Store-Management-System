package com.grocery.service;

import java.util.List;

import com.grocery.model.Category;
import com.grocery.model.Grocery;
import com.grocery.model.Store;
import com.grocery.request.CreateGroceryRequest;

public interface GroceryService {
	public Grocery createGrocery(CreateGroceryRequest req, Category category, Store store);
	
	void deleteGrocery(Long groceryId) throws Exception;
	
	public List<Grocery> getStoresGrocery(Long storeId,String groceryCategory);
	
	public List<Grocery> searchGrocery(String keyword);
	
	public Grocery findGroceryById(Long groceryId)throws Exception;
	
	public Grocery updateAvailabilityStatus(Long groceryId)throws Exception;
	
}
