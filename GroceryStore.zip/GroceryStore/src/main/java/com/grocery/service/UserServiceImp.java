package com.grocery.service;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Service;

import com.grocery.config.JwtProvider;
import com.grocery.model.Customer;
import com.grocery.repository.UserRepository;

@Service
public class UserServiceImp implements UserService{
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private JwtProvider jwtProvider;

	@Override
	public Customer findUserByJwtToken(String jwt) throws Exception {
		// TODO Auto-generated method stub
		String email = jwtProvider.getEmailFromJwtToken(jwt);
		Customer user = findUserByEmail(email);
		
		return user;
	}

	@Override
	public Customer findUserByEmail(String email) throws Exception {
		// TODO Auto-generated method stub
		Customer user = userRepository.findByEmail(email);
		if(user==null) {
			throw new Exception("User Not Found");
		}
		
		return user;
	}
	

}
