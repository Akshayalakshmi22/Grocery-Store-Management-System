package com.grocery.service;

import java.util.List;

import com.grocery.dto.StoreDto;
import com.grocery.model.Customer;
import com.grocery.model.Store;
import com.grocery.request.CreateStoreRequest;

public interface StoreService {
	public Store createStore(CreateStoreRequest req, Customer user);

	public Store updateStore(Long storeId,CreateStoreRequest updatedStore)throws Exception;
	
	public void deleteStore(Long storeId)throws Exception;
	
	public List<Store> getAllStore();
	
	public List<Store> searchStore(String keyword);//query
	
	public Store findStoreById(Long id)throws Exception;
	
	public Store getStoreByUserId(Long customerId)throws Exception;
	
	public StoreDto addToFavorites(Long storeId,Customer user)throws Exception;//add and remove.
	
	public Store updateStoreStatus(Long id)throws Exception;//open and close.
	
	
}
