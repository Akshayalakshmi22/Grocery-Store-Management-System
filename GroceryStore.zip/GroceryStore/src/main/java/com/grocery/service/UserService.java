package com.grocery.service;

import com.grocery.model.Customer;

public interface UserService {
	public Customer findUserByJwtToken(String jwt) throws Exception;

	public Customer findUserByEmail(String email) throws Exception;
}
