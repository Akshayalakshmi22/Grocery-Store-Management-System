package com.grocery.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.grocery.model.Category;
import com.grocery.model.Customer;
import com.grocery.service.CategoryService;
import com.grocery.service.UserService;

@RestController
@RequestMapping("/api/admin")
public class CategoryController {
	
	@Autowired
	private CategoryService categoryService;
	
	@Autowired
	private UserService userService;
	
	@PostMapping("/category")
	public ResponseEntity<Category> createCategory(@RequestBody Category category,
												   @RequestHeader("Authorization") String jwt)throws Exception{
		Customer user = userService.findUserByJwtToken(jwt);
		Category createdCategory = categoryService.createCategory(category.getName(), user.getCustomerId());
		return new ResponseEntity<>(createdCategory,HttpStatus.CREATED);
	}
	
	@GetMapping("/category/store")
	public ResponseEntity<List<Category>> getStoreCategory(@RequestHeader("Authorization") String jwt)throws Exception{
		Customer user = userService.findUserByJwtToken(jwt);
		List<Category> categories = categoryService.findCategoryByStoreId(user.getCustomerId());
		return new ResponseEntity<>(categories,HttpStatus.CREATED);
	}
	

}
