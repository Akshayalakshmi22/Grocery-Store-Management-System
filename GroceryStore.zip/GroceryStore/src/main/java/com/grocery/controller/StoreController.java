package com.grocery.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.grocery.dto.StoreDto;
import com.grocery.dto.StoreDto;
import com.grocery.model.Customer;
import com.grocery.model.Store;
import com.grocery.service.StoreService;
import com.grocery.service.UserService;

//Customer controller

@RestController
@RequestMapping("/api/stores")
public class StoreController {
	@Autowired
	private StoreService storeService;
	@Autowired
	private UserService userService;
	
	@GetMapping("/search")
	public ResponseEntity<List<Store>> searchStore(@RequestHeader("Authorization") String jwt,
												   @RequestParam String keyword) throws Exception{
		Customer user = userService.findUserByJwtToken(jwt);
		List<Store> store = storeService.searchStore(keyword);
		
		return new ResponseEntity<>(store, HttpStatus.OK);
	}
	
	@GetMapping()
	public ResponseEntity<List<Store>> getAllStore(@RequestHeader("Authorization") String jwt) throws Exception{
		Customer user = userService.findUserByJwtToken(jwt);
		List<Store> store = storeService.getAllStore();
		
		return new ResponseEntity<>(store, HttpStatus.OK);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Store> findStoreById(@RequestHeader("Authorization") String jwt,
			@PathVariable Long id) throws Exception{
		Customer user = userService.findUserByJwtToken(jwt);
		Store store = storeService.findStoreById(id);
		
		return new ResponseEntity<>(store, HttpStatus.OK);
	}
	
	@PutMapping("/{id}/add-favorites")
	public ResponseEntity<StoreDto> addToFavorites(@RequestHeader("Authorization") String jwt,
			                                       @PathVariable Long id) throws Exception{
		Customer user = userService.findUserByJwtToken(jwt);
		StoreDto store = storeService.addToFavorites(id, user);
		
		return new ResponseEntity<>(store, HttpStatus.OK);
	}
	
	
}
