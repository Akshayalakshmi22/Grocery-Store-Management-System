package com.grocery.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.grocery.model.Customer;
import com.grocery.model.Grocery;
import com.grocery.model.Store;
import com.grocery.request.CreateGroceryRequest;
import com.grocery.response.MessageResponse;
import com.grocery.service.GroceryService;
import com.grocery.service.StoreService;
import com.grocery.service.UserService;

@RestController
@RequestMapping("/api/admin/grocery")
public class AdminGroceryController {
	@Autowired
	private GroceryService groceryService;
	@Autowired
	private UserService userService;
	@Autowired
	private StoreService storeService; 
	
	@PostMapping
	public ResponseEntity<Grocery> createGrocery(@RequestBody CreateGroceryRequest req,
												 @RequestHeader("Authorization") String jwt) throws Exception{
		
		Customer customer = userService.findUserByJwtToken(jwt);
		Store store = storeService.findStoreById(req.getStoreId());
		Grocery grocery = groceryService.createGrocery(req, req.getCategory(), store);
		return new ResponseEntity<>(grocery, HttpStatus.CREATED);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<MessageResponse> deleteGrocery(@PathVariable Long id,
												         @RequestHeader("Authorization") String jwt) throws Exception{
		
		Customer customer = userService.findUserByJwtToken(jwt);
		groceryService.deleteGrocery(id);
		MessageResponse res = new MessageResponse();
		res.setMessage("Grocery Deleted Successfully");
		return new ResponseEntity<>(res, HttpStatus.CREATED);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Grocery> updateGroceryAvailabilityStatus(@PathVariable Long id,
												 @RequestHeader("Authorization") String jwt) throws Exception{
		
		Customer customer = userService.findUserByJwtToken(jwt);
		Grocery grocery = groceryService.updateAvailabilityStatus(id);
		
		return new ResponseEntity<>(grocery, HttpStatus.CREATED);
	}
}
