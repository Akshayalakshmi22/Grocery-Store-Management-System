package com.grocery.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.grocery.model.CartItem;

public interface CartItemRepository extends JpaRepository<CartItem,Long> {
	

}
