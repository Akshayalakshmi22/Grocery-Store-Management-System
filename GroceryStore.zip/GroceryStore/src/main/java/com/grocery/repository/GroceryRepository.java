package com.grocery.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.grocery.model.Grocery;

public interface GroceryRepository extends JpaRepository<Grocery,Long>{
	
	List<Grocery> findByStoreId(Long storeId);
	
	@Query("SELECT g.name,g.groceryCategory FROM Grocery g WHERE g.name LIKE %:keyword% OR g.groceryCategory.name LIKE %:keyword%")
	List<Grocery>searchGrocery(@Param("keyword") String keyword);

}
