package com.grocery.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.grocery.model.Cart;

public interface CartRepository extends JpaRepository<Cart,Long>{
	
	public Cart findByCustomerCustomerId(Long userId);
	

}
