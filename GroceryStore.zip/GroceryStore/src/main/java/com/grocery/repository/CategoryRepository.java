package com.grocery.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.grocery.model.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {
	
	public List<Category> findByStoreId(Long id);
}
