package com.grocery.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.grocery.model.Order;

public interface OrderRepository extends JpaRepository<Order,Long> {
	
	public List<Order> findByCustomerCustomerId(Long userId);
	
	public List<Order> findByStoreId(Long storeId);
	
	

}
