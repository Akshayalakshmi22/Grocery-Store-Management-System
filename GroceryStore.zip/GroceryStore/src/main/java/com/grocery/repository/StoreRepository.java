package com.grocery.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.grocery.model.Store;

public interface StoreRepository extends JpaRepository<Store,Long>{
	@Query("SELECT name FROM Store s WHERE lower(s.name) LIKE lower(concat('%',:keyword,'%'))") 
	List<Store> findBySearchQuery(String keyword);
	
	Store findByOwnerCustomerId(Long customerId);		
}

