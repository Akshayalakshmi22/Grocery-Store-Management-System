package com.grocery.request;

public class AddCartItemRequest {
	private Long groceryId;
	private int quantity;//grocery quantity
	public Long getGroceryId() {
		return groceryId;
	}
	public void setGroceryId(Long groceryId) {
		this.groceryId = groceryId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	

}
